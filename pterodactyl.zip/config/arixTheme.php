<?php

return [
    'license' => env('ARIX_LICENSE_KEY', ''),
];