<div class="callout">
    <i data-lucide="info"></i>
    <p>{{ $message }}</p>
</div>