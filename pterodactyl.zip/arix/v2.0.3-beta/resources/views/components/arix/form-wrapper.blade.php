<div class="form-wrapper">
    <div class="info-box">
        <h2>{{ $title }}</h2>
        <p>{{ $description }}</p>
    </div>

    <div class="wrapper-inputs">
        {{ $slot }}
    </div>
</div>