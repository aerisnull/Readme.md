<?php

return [
        /* GENERAL */
        'logo' => '/arix/Arix.png',
        'logoLight' => '/arix/Arix.png',
        'fullLogo' => false,
        'logoHeight' => '32',
        'discord' => '715281172422197300',
        'support' => 'https://discord.gg/geCjrRbAwC',

        /* ANNOUNCEMENT */
        'announcement' => false,
        'announcementColor' => '#16aaaa',
        'announcementIcon' => "megaphone",
        'announcementMessage' => 'We have a brand new game panel design!',
        'announcementCta' => false,
        'announcementCtaTitle' => 'Buy now!',
        'announcementCtaLink' => '/',
        'announcementDismissable' => false,

        /* STYLING */
        'pageTitle' => true,

        'background' => true,
        'backgroundImage' => '',
        'backgroundImageLight' => '',
        'loginBackground' => '/arix/background-login.png',
        'backgroundFaded' => 'default',

        'backdrop' => false,
        'backdropPercentage' => 100,
        
        'radiusInput' => 7,
        'radiusBox' => 10,
        'borderInput' => true,

        'flashMessage' => 1,

        'font' => 'default',
        'icon' => 'heroicons',

        /* LAYOUTS */
        'layout' => 1,
        'searchComponent' => 1,

        'logoPosition' => 1,
        'socialPosition' => 1,
        'loginLayout' => 1,

        /* COMPONENTS */
        'serverRow' => 1,
        'statsCards' => 2,
        'sideGraphs' => 2,
        'graphs' => 2,

        /* DASHBOARD WIDGETS */
        'dashboardWidgets' => [],

        /* COLORS DARKMODE */
        'primary' => '#4A35CF',
        
        'successText' => '#E1FFD8',
        'successBorder' => '#56AA2B',
        'successBackground' => '#3D8F1F',

        'dangerText' => '#FFD8D8',
        'dangerBorder' => '#AA2A2A',
        'dangerBackground' => '#8F1F20',

        'secondaryText' => '#B2B2C1',
        'secondaryBorder' => '#42425B',
        'secondaryBackground' => '#2B2B40',

        'gray50' => '#F4F4F4',
        'gray100' => '#D5D5DB',
        'gray200' => '#B2B2C1',
        'gray300' => '#8282A4',
        'gray400' => '#5E5E7F',
        'gray500' => '#42425B',
        'gray600' => '#2B2B40',
        'gray700' => '#1D1D37',
        'gray800' => '#0B0D2A',
        'gray900' => '#040519',

        /* COLORS LIGHTMODE */
        'lightmode_primary' => '#4A35CF',
        
        'lightmode_successText' => '#E1FFD8',
        'lightmode_successBorder' => '#56AA2B',
        'lightmode_successBackground' => '#3D8F1F',

        'lightmode_dangerText' => '#FFD8D8',
        'lightmode_dangerBorder' => '#AA2A2A',
        'lightmode_dangerBackground' => '#8F1F20',

        'lightmode_secondaryText' => '#46464D',
        'lightmode_secondaryBorder' => '#C0C0D3',
        'lightmode_secondaryBackground' => '#A6A7BD',

        'lightmode_gray50' => '#141415',
        'lightmode_gray100' => '#27272C',
        'lightmode_gray200' => '#46464D',
        'lightmode_gray300' => '#626272',
        'lightmode_gray400' => '#757689',
        'lightmode_gray500' => '#A6A7BD',
        'lightmode_gray600' => '#C0C0D3',
        'lightmode_gray700' => '#E7E7EF',
        'lightmode_gray800' => '#F0F1F5',
        'lightmode_gray900' => '#FFFFFF',

        /* META DATA */
        'meta_color' => '#4a35cf',
        'meta_title' => 'Pterodactyl Panel',
        'meta_description' => 'Our official Pterodactyl panel',
        'meta_image' => '/arix/meta-tags.png',
        'meta_favicon' => '/arix/Arix.png',

        /* EMAIL */
        'mail_color' => '#4a35cf',
        'mail_backgroundColor' => '#F5F5FF',
        'mail_logo' => 'https://arix.gg/arix.png',
        'mail_logoFull' => false,
        'mail_mode' => 'light',
        'mail_discord' => 'https://arix.gg/discord',
        'mail_twitter' => 'https://x.com',
        'mail_facebook' => 'https://facebook.com',
        'mail_instagram' => 'https://instagram.com',
        'mail_linkedin' => 'https://linkedin.com',
        'mail_youtube' => 'https://youtube.com',

        'mail_status' => 'https://arix.gg/status',
        'mail_billing' => 'https://arix.gg/billing',
        'mail_support' => 'https://arix.gg/support',
        
        /* Advanced */
        'profileType'       => 'gravatar',
        'modeToggler'       => true,
        'langSwitch'        => true,
        'ipFlag'            => true,
        'lowResourcesAlert' => false,
        'consolePage'       => true,
        'registration'     => false,
        'defaultMode' => 'darkmode',
        'copyright' => 'Designed by Weijers.one',

        /* SOCIALS */
        'socials' => [],
        'socialButtons' => false,
        'discordBox' => true,
];