<?php

return [
    'site_key' => env('SITE_KEY'),
    'site_secret' => env('SITE_SECRET'),
];
